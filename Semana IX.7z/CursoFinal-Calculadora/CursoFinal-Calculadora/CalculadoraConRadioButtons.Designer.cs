﻿namespace CursoFinal_Calculadora
{
    partial class CalculadoraConRadioButtons
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rdbSumar = new System.Windows.Forms.RadioButton();
            this.rdbRestar = new System.Windows.Forms.RadioButton();
            this.rdbMultiplicar = new System.Windows.Forms.RadioButton();
            this.rdbDividir = new System.Windows.Forms.RadioButton();
            this.btnResolver = new System.Windows.Forms.Button();
            this.txtOperando2 = new System.Windows.Forms.TextBox();
            this.txtOperando1 = new System.Windows.Forms.TextBox();
            this.lblResultado = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblRes = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // rdbSumar
            // 
            this.rdbSumar.AutoSize = true;
            this.rdbSumar.Location = new System.Drawing.Point(22, 98);
            this.rdbSumar.Name = "rdbSumar";
            this.rdbSumar.Size = new System.Drawing.Size(55, 17);
            this.rdbSumar.TabIndex = 0;
            this.rdbSumar.TabStop = true;
            this.rdbSumar.Text = "Sumar";
            this.rdbSumar.UseVisualStyleBackColor = true;
            // 
            // rdbRestar
            // 
            this.rdbRestar.AutoSize = true;
            this.rdbRestar.Location = new System.Drawing.Point(22, 121);
            this.rdbRestar.Name = "rdbRestar";
            this.rdbRestar.Size = new System.Drawing.Size(56, 17);
            this.rdbRestar.TabIndex = 1;
            this.rdbRestar.TabStop = true;
            this.rdbRestar.Text = "Restar";
            this.rdbRestar.UseVisualStyleBackColor = true;
            // 
            // rdbMultiplicar
            // 
            this.rdbMultiplicar.AutoSize = true;
            this.rdbMultiplicar.Location = new System.Drawing.Point(22, 144);
            this.rdbMultiplicar.Name = "rdbMultiplicar";
            this.rdbMultiplicar.Size = new System.Drawing.Size(72, 17);
            this.rdbMultiplicar.TabIndex = 2;
            this.rdbMultiplicar.TabStop = true;
            this.rdbMultiplicar.Text = "Multiplicar";
            this.rdbMultiplicar.UseVisualStyleBackColor = true;
            // 
            // rdbDividir
            // 
            this.rdbDividir.AutoSize = true;
            this.rdbDividir.Location = new System.Drawing.Point(22, 167);
            this.rdbDividir.Name = "rdbDividir";
            this.rdbDividir.Size = new System.Drawing.Size(54, 17);
            this.rdbDividir.TabIndex = 3;
            this.rdbDividir.TabStop = true;
            this.rdbDividir.Text = "Dividir";
            this.rdbDividir.UseVisualStyleBackColor = true;
            // 
            // btnResolver
            // 
            this.btnResolver.Location = new System.Drawing.Point(113, 147);
            this.btnResolver.Name = "btnResolver";
            this.btnResolver.Size = new System.Drawing.Size(75, 23);
            this.btnResolver.TabIndex = 4;
            this.btnResolver.Text = "Resolver";
            this.btnResolver.UseVisualStyleBackColor = true;
            this.btnResolver.Click += new System.EventHandler(this.btnResolver_Click);
            // 
            // txtOperando2
            // 
            this.txtOperando2.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtOperando2.Location = new System.Drawing.Point(113, 121);
            this.txtOperando2.Name = "txtOperando2";
            this.txtOperando2.Size = new System.Drawing.Size(100, 20);
            this.txtOperando2.TabIndex = 5;
            // 
            // txtOperando1
            // 
            this.txtOperando1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtOperando1.Location = new System.Drawing.Point(113, 95);
            this.txtOperando1.Name = "txtOperando1";
            this.txtOperando1.Size = new System.Drawing.Size(100, 20);
            this.txtOperando1.TabIndex = 6;
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Location = new System.Drawing.Point(78, 213);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(0, 13);
            this.lblResultado.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(153, 173);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(112, 173);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Resultado";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // lblRes
            // 
            this.lblRes.AutoSize = true;
            this.lblRes.Location = new System.Drawing.Point(173, 173);
            this.lblRes.Name = "lblRes";
            this.lblRes.Size = new System.Drawing.Size(10, 13);
            this.lblRes.TabIndex = 10;
            this.lblRes.Text = " ";
            // 
            // CalculadoraConRadioButtons
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(629, 420);
            this.Controls.Add(this.lblRes);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.txtOperando1);
            this.Controls.Add(this.txtOperando2);
            this.Controls.Add(this.btnResolver);
            this.Controls.Add(this.rdbDividir);
            this.Controls.Add(this.rdbMultiplicar);
            this.Controls.Add(this.rdbRestar);
            this.Controls.Add(this.rdbSumar);
            this.Name = "CalculadoraConRadioButtons";
            this.Text = "CalculadoraConRadioButtons";
            this.Load += new System.EventHandler(this.CalculadoraConRadioButtons_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton rdbSumar;
        private System.Windows.Forms.RadioButton rdbRestar;
        private System.Windows.Forms.RadioButton rdbMultiplicar;
        private System.Windows.Forms.RadioButton rdbDividir;
        private System.Windows.Forms.Button btnResolver;
        private System.Windows.Forms.TextBox txtOperando2;
        private System.Windows.Forms.TextBox txtOperando1;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblRes;
    }
}