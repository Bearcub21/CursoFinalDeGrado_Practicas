﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CursoFinal_Calculadora
{
    public partial class CalculadoraConRadioButtons : Form
    {
        public CalculadoraConRadioButtons()
        {
            InitializeComponent();
        }

        private void CalculadoraConRadioButtons_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnResolver_Click(object sender, EventArgs e)
        {
            if (rdbSumar.Checked == true)
            {
                if ((txtOperando1.Text == "") || (txtOperando2.Text == ""))
                {
                    MessageBox.Show("Verifique los campos");
                }               
                lblRes.Text = (float.Parse(txtOperando1.Text) + float.Parse(txtOperando2.Text)).ToString();
            }
            else if (rdbRestar.Checked == true)
            {
                if ((txtOperando1.Text == "") || (txtOperando2.Text == ""))
                {
                    MessageBox.Show("Verifique los campos");
                }
                lblRes.Text = (float.Parse(txtOperando1.Text) - float.Parse(txtOperando2.Text)).ToString();
            }
            else if (rdbMultiplicar.Checked == true)
            {
                if ((txtOperando1.Text == "") || (txtOperando2.Text == ""))
                {
                    MessageBox.Show("Verifique los campos");
                }
                lblRes.Text = (float.Parse(txtOperando1.Text) * float.Parse(txtOperando2.Text)).ToString();
            }
            else if (rdbDividir.Checked == true)
            {
                if ((txtOperando1.Text == "") || (txtOperando2.Text == ""))
                {
                    MessageBox.Show("Verifique los campos");
                }
                else if (txtOperando2.Text == "0")
                {
                    MessageBox.Show("Division por 0 no definida");
                }
                lblRes.Text = (float.Parse(txtOperando1.Text) / float.Parse(txtOperando2.Text)).ToString();
            }
        }
    }
}
