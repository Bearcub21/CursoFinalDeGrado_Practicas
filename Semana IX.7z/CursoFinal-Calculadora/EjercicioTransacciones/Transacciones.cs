﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioTransacciones
{
    public class Transacciones
    {
        //init fields

        public List<float> depositos;
        public List<float> retiros;


        //methods

        public Transacciones()
        {
            depositos = new List<float>();
            retiros = new List<float>(); 
        }

        public void Depositar(float deposito)
        {
            depositos.Add(deposito);
        }

        public void Retirar(float retiro)
        {
            retiros.Add(retiro);
        }

    }
}
