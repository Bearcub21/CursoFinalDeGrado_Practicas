﻿namespace EjercicioTransacciones
{
    partial class ElVenezolano
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnTransaccion = new System.Windows.Forms.Button();
            this.rdbRetirar = new System.Windows.Forms.RadioButton();
            this.rdbDepositar = new System.Windows.Forms.RadioButton();
            this.txtTransaccion = new System.Windows.Forms.TextBox();
            this.btnCapital = new System.Windows.Forms.Button();
            this.txtCapital = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnTransaccion
            // 
            this.btnTransaccion.Location = new System.Drawing.Point(273, 164);
            this.btnTransaccion.Name = "btnTransaccion";
            this.btnTransaccion.Size = new System.Drawing.Size(75, 23);
            this.btnTransaccion.TabIndex = 0;
            this.btnTransaccion.Text = "Ingresar";
            this.btnTransaccion.UseVisualStyleBackColor = true;
            this.btnTransaccion.Click += new System.EventHandler(this.btnTransaccion_Click);
            // 
            // rdbRetirar
            // 
            this.rdbRetirar.AutoSize = true;
            this.rdbRetirar.Location = new System.Drawing.Point(221, 193);
            this.rdbRetirar.Name = "rdbRetirar";
            this.rdbRetirar.Size = new System.Drawing.Size(56, 17);
            this.rdbRetirar.TabIndex = 1;
            this.rdbRetirar.TabStop = true;
            this.rdbRetirar.Text = "Retirar";
            this.rdbRetirar.UseVisualStyleBackColor = true;
            // 
            // rdbDepositar
            // 
            this.rdbDepositar.AutoSize = true;
            this.rdbDepositar.Location = new System.Drawing.Point(344, 193);
            this.rdbDepositar.Name = "rdbDepositar";
            this.rdbDepositar.Size = new System.Drawing.Size(70, 17);
            this.rdbDepositar.TabIndex = 2;
            this.rdbDepositar.TabStop = true;
            this.rdbDepositar.Text = "Depositar";
            this.rdbDepositar.UseVisualStyleBackColor = true;
            // 
            // txtTransaccion
            // 
            this.txtTransaccion.Location = new System.Drawing.Point(259, 138);
            this.txtTransaccion.Name = "txtTransaccion";
            this.txtTransaccion.Size = new System.Drawing.Size(100, 20);
            this.txtTransaccion.TabIndex = 3;
            // 
            // btnCapital
            // 
            this.btnCapital.Location = new System.Drawing.Point(273, 225);
            this.btnCapital.Name = "btnCapital";
            this.btnCapital.Size = new System.Drawing.Size(75, 23);
            this.btnCapital.TabIndex = 4;
            this.btnCapital.Text = "Capital";
            this.btnCapital.UseVisualStyleBackColor = true;
            this.btnCapital.Click += new System.EventHandler(this.btnCapital_Click);
            // 
            // txtCapital
            // 
            this.txtCapital.Location = new System.Drawing.Point(259, 254);
            this.txtCapital.Name = "txtCapital";
            this.txtCapital.Size = new System.Drawing.Size(100, 20);
            this.txtCapital.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(639, 331);
            this.Controls.Add(this.txtCapital);
            this.Controls.Add(this.btnCapital);
            this.Controls.Add(this.txtTransaccion);
            this.Controls.Add(this.rdbDepositar);
            this.Controls.Add(this.rdbRetirar);
            this.Controls.Add(this.btnTransaccion);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnTransaccion;
        private System.Windows.Forms.RadioButton rdbRetirar;
        private System.Windows.Forms.RadioButton rdbDepositar;
        private System.Windows.Forms.TextBox txtTransaccion;
        private System.Windows.Forms.Button btnCapital;
        private System.Windows.Forms.TextBox txtCapital;
    }
}

