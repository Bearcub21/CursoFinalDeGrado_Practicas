﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EjercicioTransacciones
{
    public partial class ElVenezolano : Form
    {
        Transacciones trans = new Transacciones();
        float capital = 0; 

        public ElVenezolano()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnTransaccion_Click(object sender, EventArgs e)
        {
            if (rdbDepositar.Checked == true)
            {
                trans.Depositar(float.Parse(txtTransaccion.Text));
                txtTransaccion.Text = "";
            }
            else if (rdbRetirar.Checked == true)
            {
                trans.Retirar(float.Parse(txtTransaccion.Text));
                txtTransaccion.Text = "";
            }
        }

        private void btnCapital_Click(object sender, EventArgs e)
        {
            float totalDepositos = 0;
            float totalRetiros = 0;

            foreach (float deposito in trans.depositos)
            {
                totalDepositos += deposito;
            }

            foreach (float retiro in trans.retiros)
            {
                totalRetiros += retiro;
            }

            capital = totalDepositos - totalRetiros;

            txtCapital.Text = capital.ToString();
        }
    }
}
