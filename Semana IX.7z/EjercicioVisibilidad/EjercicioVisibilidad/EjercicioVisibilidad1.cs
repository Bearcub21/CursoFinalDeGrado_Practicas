﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EjercicioVisibilidad
{
    public partial class EjercicioVisibilidad1 : Form
    {
        public EjercicioVisibilidad1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (this.label1.Visible == true)
            {
                this.label1.Visible = false;
            }
            else if (this.label1.Visible == false)
            {
                this.label1.Visible = true;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
