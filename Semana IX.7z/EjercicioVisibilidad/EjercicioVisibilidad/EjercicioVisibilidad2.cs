﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EjercicioVisibilidad
{
    public partial class EjercicioVisibilidad2 : Form
    {
        public EjercicioVisibilidad2()
        {
            InitializeComponent();
        }

        private void btnComparar_Click(object sender, EventArgs e)
        {

            lblFlecha1.Visible = false;
            lblFlecha2.Visible = false;
            lblFlecha3.Visible = false;

            float ele1 = float.Parse(txtElemento1.Text);
            float ele2 = float.Parse(txtElemento2.Text);
            float ele3 = float.Parse(txtElemento3.Text);

            if ((ele1 > ele2) && (ele1 > ele3))
            {
                lblFlecha1.Visible = true;
            }
            else if ((ele2 > ele3) && (ele2 > ele1))
            {
                lblFlecha2.Visible = true;
            }
            else if ((ele3 > ele1) && (ele3 > ele2))
            {
                lblFlecha3.Visible = true;
            }
            else if (((ele1 == ele2) && (ele2 == ele3)) || ((ele3 == ele2) && (ele2 == ele1)))
            {
                lblFlecha1.Visible = true;
                lblFlecha2.Visible = true;
                lblFlecha3.Visible = true;
            }

        }
    }
}
