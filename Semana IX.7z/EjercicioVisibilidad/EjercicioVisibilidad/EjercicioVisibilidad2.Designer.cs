﻿namespace EjercicioVisibilidad
{
    partial class EjercicioVisibilidad2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnComparar = new System.Windows.Forms.Button();
            this.lblFlecha1 = new System.Windows.Forms.Label();
            this.lblFlecha2 = new System.Windows.Forms.Label();
            this.lblFlecha3 = new System.Windows.Forms.Label();
            this.txtElemento3 = new System.Windows.Forms.TextBox();
            this.txtElemento2 = new System.Windows.Forms.TextBox();
            this.txtElemento1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnComparar
            // 
            this.btnComparar.Location = new System.Drawing.Point(272, 146);
            this.btnComparar.Name = "btnComparar";
            this.btnComparar.Size = new System.Drawing.Size(75, 23);
            this.btnComparar.TabIndex = 0;
            this.btnComparar.Text = "Comparar";
            this.btnComparar.UseVisualStyleBackColor = true;
            this.btnComparar.Click += new System.EventHandler(this.btnComparar_Click);
            // 
            // lblFlecha1
            // 
            this.lblFlecha1.AutoSize = true;
            this.lblFlecha1.Location = new System.Drawing.Point(193, 102);
            this.lblFlecha1.Name = "lblFlecha1";
            this.lblFlecha1.Size = new System.Drawing.Size(13, 13);
            this.lblFlecha1.TabIndex = 1;
            this.lblFlecha1.Text = "^";
            this.lblFlecha1.Visible = false;
            // 
            // lblFlecha2
            // 
            this.lblFlecha2.AutoSize = true;
            this.lblFlecha2.Location = new System.Drawing.Point(297, 102);
            this.lblFlecha2.Name = "lblFlecha2";
            this.lblFlecha2.Size = new System.Drawing.Size(13, 13);
            this.lblFlecha2.TabIndex = 2;
            this.lblFlecha2.Text = "^";
            this.lblFlecha2.Visible = false;
            // 
            // lblFlecha3
            // 
            this.lblFlecha3.AutoSize = true;
            this.lblFlecha3.Location = new System.Drawing.Point(408, 102);
            this.lblFlecha3.Name = "lblFlecha3";
            this.lblFlecha3.Size = new System.Drawing.Size(13, 13);
            this.lblFlecha3.TabIndex = 3;
            this.lblFlecha3.Text = "^\r";
            this.lblFlecha3.Visible = false;
            // 
            // txtElemento3
            // 
            this.txtElemento3.Location = new System.Drawing.Point(365, 79);
            this.txtElemento3.Name = "txtElemento3";
            this.txtElemento3.Size = new System.Drawing.Size(100, 20);
            this.txtElemento3.TabIndex = 4;
            // 
            // txtElemento2
            // 
            this.txtElemento2.Location = new System.Drawing.Point(259, 79);
            this.txtElemento2.Name = "txtElemento2";
            this.txtElemento2.Size = new System.Drawing.Size(100, 20);
            this.txtElemento2.TabIndex = 5;
            // 
            // txtElemento1
            // 
            this.txtElemento1.Location = new System.Drawing.Point(153, 79);
            this.txtElemento1.Name = "txtElemento1";
            this.txtElemento1.Size = new System.Drawing.Size(100, 20);
            this.txtElemento1.TabIndex = 6;
            // 
            // EjercicioVisibilidad2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(648, 338);
            this.Controls.Add(this.txtElemento1);
            this.Controls.Add(this.txtElemento2);
            this.Controls.Add(this.txtElemento3);
            this.Controls.Add(this.lblFlecha3);
            this.Controls.Add(this.lblFlecha2);
            this.Controls.Add(this.lblFlecha1);
            this.Controls.Add(this.btnComparar);
            this.Name = "EjercicioVisibilidad2";
            this.Text = "EjercicioVisibilidad2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnComparar;
        private System.Windows.Forms.Label lblFlecha1;
        private System.Windows.Forms.Label lblFlecha2;
        private System.Windows.Forms.Label lblFlecha3;
        private System.Windows.Forms.TextBox txtElemento3;
        private System.Windows.Forms.TextBox txtElemento2;
        private System.Windows.Forms.TextBox txtElemento1;
    }
}